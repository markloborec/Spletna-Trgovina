import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Subscription, finalize } from 'rxjs';

import { CartService } from '../services/cart.service';
import { AuthService } from '../services/auth.service';
import { API_BASE_URL } from '../services/api.config';

type PaymentMethod = 'card' | 'cod' | 'bank';
type DeliveryMethod = 'courier' | 'pickup';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [CommonModule, CurrencyPipe, FormsModule],
  templateUrl: './cart.html',
  styleUrl: './cart.scss',
})
export class Cart implements OnInit, OnDestroy {
  // ---- nastavitve (lahko kasneje prestaviš v config) ----
  readonly VAT_RATE = 0.22;         // 22% DDV (spremeni po potrebi)
  readonly SHIPPING_FLAT = 4.90;    // fiksna dostava
  readonly FREE_SHIPPING_OVER = 50; // nad tem je dostava 0

  // ---- UI state ----
  isLoggedIn = false;
  private sub?: Subscription;

  payment: PaymentMethod = 'card';
  delivery: DeliveryMethod = 'courier';

  guestAddress = {
    fullName: '',
    street: '',
    city: '',
    postalCode: '',
    phone: '',
  };

  isPlacingOrder = false;
  errorMessage = '';
  successMessage = '';

  private readonly ordersUrl = `${API_BASE_URL}/orders`;

  constructor(
    public cart: CartService,
    private auth: AuthService,
    private http: HttpClient
  ) { }

  ngOnInit(): void {
    this.sub = this.auth.isLoggedIn$.subscribe(v => (this.isLoggedIn = v));
  }

  ngOnDestroy(): void {
    this.sub?.unsubscribe();
  }

  // ---- izračuni ----
  get itemsTotal(): number {
    return this.cart.totalPrice; // predpostavljamo, da je to seštevek postavk
  }

  get taxAmount(): number {
    // Če so cene že z DDV, potem tega NE računaj tako.
    // Za zdaj predpostavimo: cene so brez DDV, DDV dodamo tukaj.
    return this.itemsTotal * this.VAT_RATE;
  }

  get shippingCost(): number {
    if (this.delivery === 'pickup') return 0;
    if (this.itemsTotal >= this.FREE_SHIPPING_OVER) return 0;
    return this.SHIPPING_FLAT;
  }

  get grandTotal(): number {
    return this.itemsTotal + this.taxAmount + this.shippingCost;
  }

  // ---- cart akcije ----
  remove(id: string) {
    this.cart.remove(id);
  }

  setQty(id: string, value: any) {
    this.cart.setQty(id, Number(value));
  }

  clear() {
    this.cart.clear();
    this.resetMessages();
  }

  // ---- checkout ----
  private resetMessages() {
    this.errorMessage = '';
    this.successMessage = '';
  }

  private validateGuestAddress(): string | null {
    if (this.isLoggedIn) return null;
    if (this.delivery === 'pickup') return null; // prevzem ne rabi naslova

    const a = this.guestAddress;
    if (!a.fullName || !a.street || !a.city || !a.postalCode || !a.phone) {
      return 'Prosimo, izpolni vse podatke za dostavo.';
    }
    return null;
  }

  placeOrder() {
    this.resetMessages();

    if (this.cart.items.length === 0) {
      this.errorMessage = 'Košarica je prazna.';
      return;
    }

    const guestError = this.validateGuestAddress();
    if (guestError) {
      this.errorMessage = guestError;
      return;
    }

    this.isPlacingOrder = true;

    // Payload za backend (POST /api/orders)
    const payload = {
      items: this.cart.items.map(it => ({
        productId: it.product.id,
        name: it.product.name,
        qty: it.qty,
        unitPrice: it.product.price,
        lineTotal: it.qty * it.product.price,
      })),
      payment: this.payment,
      delivery: this.delivery,
      totals: {
        itemsTotal: this.itemsTotal,
        tax: this.taxAmount,
        shipping: this.shippingCost,
        grandTotal: this.grandTotal,
      },
      guestAddress: this.isLoggedIn ? null : (this.delivery === 'pickup' ? null : this.guestAddress),
    };

    const token = this.auth.getToken();
    const headers = token ? new HttpHeaders({ Authorization: `Bearer ${token}` }) : new HttpHeaders();

    this.http
      .post<{ orderId: string }>(this.ordersUrl, payload, { headers })
      .pipe(finalize(() => (this.isPlacingOrder = false)))
      .subscribe({
        next: (res) => {
          this.successMessage = `Naročilo je bilo oddano. Št. naročila: ${res.orderId}`;
          this.cart.clear();
        },
        error: (err: HttpErrorResponse) => {
          const code = (err?.error?.error ?? '').toString();
          if (code === 'ORDER_EMPTY') this.errorMessage = 'Košarica je prazna.';
          else if (code === 'ORDER_INVALID_ITEM') this.errorMessage = 'Nekatere postavke v košarici niso veljavne.';
          else if (code === 'ORDER_CREATE_FAILED') this.errorMessage = 'Pri oddaji naročila je prišlo do napake. Poskusi znova.';
          else this.errorMessage = 'Ne morem oddati naročila. Preveri povezavo do backend-a in poskusi znova.';
        },
      });
  }
}
