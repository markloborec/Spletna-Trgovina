import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, of, map } from 'rxjs';
import { Bicycle, Clothing, Equipment, Product, ProductType } from '../models/product';
import { ProductFactory } from '../models/product-factory';
import { API_BASE_URL } from './api.config';

export type ConcreteProduct = Bicycle | Clothing | Equipment;

interface ProductsListResponse {
  items: any[];
  total: number;
  page: number;
  pageSize: number;
}

type GetAllParams = {
  type?: ProductType;   // 'cycles' | 'equipment' | 'clothing'
  page?: number;
  pageSize?: number;
};

@Injectable({ providedIn: 'root' })
export class ProductService {
  private readonly apiUrl = `${API_BASE_URL}/products`;

  constructor(private http: HttpClient) {}

  /** Map backend -> frontend Product (base), nato ProductFactory ustvari pravilen concrete model */
  private mapBackendProduct(p: any, fallbackType?: ProductType): ConcreteProduct {
    const base: Product = {
      id: (p.id ?? p._id)?.toString(),
      name: p.name,
      price: Number(p.price ?? 0),

      imageUrl: p.imageUrl ?? p.image_url ?? '',
      shortDescription: p.shortDescription ?? p.short_description ?? '',
      longDescription: p.longDescription ?? p.long_description ?? '',

      type: (p.type as ProductType) ?? fallbackType ?? 'equipment',

      isAvailable: (p.isAvailable ?? p.inStock) ?? true,

      warrantyMonths: Number(p.warrantyMonths ?? 24),

      officialProductSite: p.officialProductSite,
    };

    return ProductFactory.create({
      ...base,
      brand: p.brand,
      material: p.material,
      weight: p.weight,
      compatibility: p.compatibility,
    } as any) as ConcreteProduct;
  }

  /** Najboljši način: backend filtrira, ne frontend */
  getAll(params: GetAllParams = {}): Observable<ConcreteProduct[]> {
    let httpParams = new HttpParams();
    if (params.type) httpParams = httpParams.set('type', params.type);
    if (params.page) httpParams = httpParams.set('page', String(params.page));
    if (params.pageSize) httpParams = httpParams.set('pageSize', String(params.pageSize));

    return this.http.get<ProductsListResponse>(this.apiUrl, { params: httpParams }).pipe(
      map((res) => (res.items ?? []).map((p) => this.mapBackendProduct(p, params.type)))
    );
  }

  /** Convenience metode */
  getBicycles(pageSize = 100): Observable<Bicycle[]> {
    return this.getAll({ type: 'cycles', pageSize }) as Observable<Bicycle[]>;
  }

  getClothing(pageSize = 100): Observable<Clothing[]> {
    return this.getAll({ type: 'clothing', pageSize }) as Observable<Clothing[]>;
  }

  getEquipment(pageSize = 100): Observable<Equipment[]> {
    return this.getAll({ type: 'equipment', pageSize }) as Observable<Equipment[]>;
  }

  getById(id: string): Observable<ConcreteProduct> {
    return this.http.get<any>(`${this.apiUrl}/${id}`).pipe(
      map((p) => this.mapBackendProduct(p))
    );
  }

  /**
   * POST - kreiraj nov produkt
   * ❗ Backend trenutno nima POST /api/products.
   */
  create(product: Product): Observable<ConcreteProduct> {
    return of(ProductFactory.create(product) as ConcreteProduct);
  }

  /**
   * PATCH/PUT - posodobi obstoječ produkt
   * ❗ Backend še nima update endpointa – placeholder.
   */
  update(id: string, changes: Partial<Product>): Observable<ConcreteProduct> {
    return of(ProductFactory.create({ ...(changes as Product), id } as any) as ConcreteProduct);
  }

  /**
   * DELETE - odstrani produkt
   * ❗ Backend še nima DELETE /api/products/:id – placeholder.
   */
  delete(_id: string): Observable<void> {
    return of(void 0);
  }
}
