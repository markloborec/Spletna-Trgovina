import { Component } from '@angular/core';
import { CartService } from '../../../services/cart.service';

@Component({
  selector: 'app-cart',
  imports: [],
  templateUrl: './cart.html',
  styleUrl: './cart.scss',
})
export class Cart {
  constructor(public cart: CartService) { }

  remove(id: string) {
    this.cart.remove(id);
  }

  setQty(id: string, qty: number) {
    this.cart.setQty(id, qty);
  }

  clear() {
    this.cart.clear();
  }
}
