import { Component } from '@angular/core';

@Component({
  selector: 'app-product-info',
  imports: [],
  templateUrl: './product-info.html',
  styleUrl: './product-info.scss',
})
export class ProductInfo {

}
