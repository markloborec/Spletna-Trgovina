import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductService, ProductReviewDto } from '../../../services/product.service';

@Component({
  selector: 'app-product-info',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './product-info.html',
  styleUrls: ['./product-info.scss']
})
export class ProductInfo implements OnChanges {
  @Input() product: any;
  @Output() close = new EventEmitter<void>();

  // v modalu držimo "svež" produkt iz backenda (zaradi ratingAvg/ratingCount ipd.)
  productFull: any = null;

  reviews: ProductReviewDto[] = [];
  loadingProduct = false;
  loadingReviews = false;
  reviewsError = '';

  constructor(private productService: ProductService) { }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['product']) {
      const id = this.product?.id;
      if (id) {
        this.loadProductAndReviews(String(id));
      } else {
        this.productFull = this.product;
        this.reviews = [];
      }
    }
  }

  closeModal() {
    this.close.emit();
  }

  private loadProductAndReviews(id: string) {
    this.productFull = this.product; // fallback, dokler ne pride svež response

    this.loadingProduct = true;
    this.productService.getById(id).subscribe({
      next: (p) => {
        this.productFull = p;
        this.loadingProduct = false;
      },
      error: () => {
        // če ne uspe, še vedno pokažemo input product
        this.loadingProduct = false;
      }
    });

    this.loadingReviews = true;
    this.reviewsError = '';
    this.productService.getProductReviews(id).subscribe({
      next: (items) => {
        this.reviews = items ?? [];
        this.loadingReviews = false;
      },
      error: () => {
        this.reviewsError = 'Mnenj ni bilo mogoče naložiti.';
        this.loadingReviews = false;
      }
    });
  }

  get avgRating(): number {
    const p = this.productFull ?? this.product;
    const avg = p?.ratingAvg;
    if (typeof avg === 'number') return avg;

    // fallback: izračunaj iz reviewev
    if (!this.reviews?.length) return 0;
    const sum = this.reviews.reduce((acc, r) => acc + Number(r.rating || 0), 0);
    return sum / this.reviews.length;
  }

  get ratingCount(): number {
    const p = this.productFull ?? this.product;
    const cnt = p?.ratingCount;
    if (typeof cnt === 'number') return cnt;
    return this.reviews?.length ?? 0;
  }

  // prikaz zvezdic (1..5)
  starsFilled(i: number): boolean {
    // za UI: zaokroži na najbližjo polovico, potem na polne
    const rounded = Math.round(this.avgRating * 2) / 2;
    return i <= Math.round(rounded);
  }
}
