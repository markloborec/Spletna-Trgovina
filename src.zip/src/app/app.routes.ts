import { Routes } from '@angular/router';
import { Homepage } from './homepage/homepage';
import { Registration } from './dialogs/registration/registration';

export const routes: Routes = [
    { path: '', component: Homepage },
    //{ path: 'registration', component: Registration },

];
