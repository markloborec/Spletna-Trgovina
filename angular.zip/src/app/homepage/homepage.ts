import { Component } from '@angular/core';

@Component({
  selector: 'app-homepage',
  standalone: true,
  templateUrl: './homepage.html',
  styleUrls: ['./homepage.scss'],
})
export class Homepage {}
