import { Router } from "express";
import { Product } from "../models/Product";
import { authRouter } from "./authRoutes";
import { verifyToken } from "../utils/jwt";
import { User } from "../models/User";
import { Order } from "../models/Order";

export const router = Router();

router.get("/health", (req, res) => {
  res.json({ status: "ok" });
});

// auth pod /api/auth/...
router.use("/auth", authRouter);

/**
 * POST /api/orders
 * Shrani naročilo v MongoDB (podobno kot User.create pri registraciji).
 * - validira items
 * - če je Bearer token, poveže naročilo z userjem
 * - ustvari Order dokument
 * - vrne orderId (= Mongo _id)
 */
router.post("/orders", async (req, res) => {
  try {
    const body = req.body ?? {};

    const items = Array.isArray(body.items) ? body.items : [];
    if (items.length === 0) {
      return res.status(400).json({ error: "ORDER_EMPTY" });
    }

    for (const it of items) {
      const productId = (it?.productId ?? "").toString().trim();
      const name = (it?.name ?? "").toString().trim();
      const qty = Number(it?.qty);
      const unitPrice = Number(it?.unitPrice);
      const lineTotal = Number(it?.lineTotal);

      if (!productId || !name) {
        return res.status(400).json({ error: "ORDER_INVALID_ITEM" });
      }
      if (!Number.isFinite(qty) || qty <= 0) {
        return res.status(400).json({ error: "ORDER_INVALID_ITEM" });
      }
      if (!Number.isFinite(unitPrice) || unitPrice < 0) {
        return res.status(400).json({ error: "ORDER_INVALID_ITEM" });
      }
      if (!Number.isFinite(lineTotal) || lineTotal < 0) {
        return res.status(400).json({ error: "ORDER_INVALID_ITEM" });
      }
    }

    // totals validacija (osnovna)
    const totals = body.totals ?? {};
    const itemsTotal = Number(totals.itemsTotal);
    const tax = Number(totals.tax);
    const shipping = Number(totals.shipping);
    const grandTotal = Number(totals.grandTotal);

    if (
      !Number.isFinite(itemsTotal) || itemsTotal < 0 ||
      !Number.isFinite(tax) || tax < 0 ||
      !Number.isFinite(shipping) || shipping < 0 ||
      !Number.isFinite(grandTotal) || grandTotal < 0
    ) {
      return res.status(400).json({ error: "ORDER_INVALID_TOTALS" });
    }

    const payment = (body.payment ?? "").toString().trim();
    const delivery = (body.delivery ?? "").toString().trim();
    if (!payment || !delivery) {
      return res.status(400).json({ error: "ORDER_MISSING_FIELDS" });
    }

    // opcijsko: preberi userja iz JWT (guest order dovoljen)
    let user_id: any = null;
    let user_email = "";

    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith("Bearer ")) {
      try {
        const token = authHeader.split(" ")[1];
        const payload = verifyToken(token);

        // preveri, da user še obstaja (enako kot authMiddleware)
        const dbUser = await User.findById(payload.userId).lean();
        if (dbUser) {
          user_id = dbUser._id;
          user_email = (dbUser.email ?? "").toString();
        }
      } catch {
        // če token ne velja, naročila ne ustavimo (guest)
        user_id = null;
        user_email = "";
      }
    }

    // guestAddress: lahko je null
    const guestAddress = body.guestAddress ?? null;

    // SHRANI v MongoDB (tako kot User.create)
    const order = await Order.create({
      user_id,
      user_email,
      items,
      payment,
      delivery,
      totals: { itemsTotal, tax, shipping, grandTotal },
      guestAddress,
      status: "created",
    });

    console.log("[ORDER SAVED]", {
      orderId: order._id.toString(),
      user_id: user_id ? user_id.toString() : null,
      user_email,
      itemsCount: items.length,
      payment,
      delivery,
    });

    return res.status(201).json({ orderId: order._id.toString() });
  } catch (error) {
    console.error("Error creating order:", error);
    return res.status(500).json({ error: "ORDER_CREATE_FAILED" });
  }
});

// debug products
router.get("/debug/products", async (req, res) => {
  try {
    const products = await Product.find().limit(5).lean();
    res.json(products);
  } catch (error) {
    console.error("Error fetching products:", error);
    res.status(500).json({ error: "MONGO_ERROR" });
  }
});
